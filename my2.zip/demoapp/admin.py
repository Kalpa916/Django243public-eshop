from django.contrib import admin
from .models import Customer,Vehicle,SignUp,Order2
# Register your models here.
admin.site.register(Customer)
admin.site.register(Vehicle)
admin.site.register(SignUp)
admin.site.register(Order2)