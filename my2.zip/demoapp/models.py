
from django.db import models

import datetime
class SignUp(models.Model):
    first_name = models.CharField(max_length=20)
    phone = models.CharField(max_length=20)
    email = models.EmailField()
    password1 = models.CharField(max_length=200)
    print(password1)
    
    @property
    def isexists(self):
        if(SignUp.objects.filter(email=self.email)):
            return False
        return True

    @staticmethod
    def get_customer_by_email(email):
        try:
            return SignUp.objects.get(email=email)
        except:
            return False

   


class Customer(models.Model):
    name = models.CharField(max_length=255)

    @staticmethod
    def get_all_customer():
        return Customer.objects.all()


class Vehicle(models.Model):
    name = models.CharField(max_length=255)
    customer = models.ForeignKey(
        Customer,
        on_delete=models.CASCADE,
        related_name='Vehicle'
    )
    @staticmethod
    def get_products_by_id(ids):
            return Vehicle.objects.filter(id__in=ids)

    @staticmethod
    def get_all_products():
        return Vehicle.objects.all()

    @staticmethod
    def get_all_products_by_category_id(customer_id):
        if(customer_id):
            return Vehicle.objects.filter(customer=customer_id)
        else:
            return Vehicle.get_all_products()
class Order2(models.Model):
    Vehicle=models.ForeignKey(Vehicle,on_delete=models.CASCADE)
    Customer=models.ForeignKey(Customer,on_delete=models.CASCADE)
    quantity=models.IntegerField(default=1)
    price=models.IntegerField()
    phone=models.CharField(max_length=10)
    date=models.DateField(default=datetime.datetime.today)
    
    
    def place_order(self):
        self.save()
    @staticmethod
    def get_orders_by_customer(customer_id):
        Order2.objects.filter(Customer=customer_id)
        
        