
from django import template
register=template.Library()


@register.filter(name='is_in_cart')
def is_in_cart(nmeds,cart):
    #print(nmeds.id)
    k=cart.keys()
    for m in k:
        if(m=='null'):
            continue
        if(int(m)==nmeds.id):
            print(nmeds.id)
            return True
    return False
        
            
@register.filter(name='cart_quanity')
def cart_quanity(nmeds,cart):
    k=cart.keys()
    for m in k:
        if(m=='null'):
            continue
        if(int(m)==nmeds.id):
            return cart.get(m)
    return 0
    
    
    
@register.filter(name='price_total')
def price_total(nmeds,cart):
    nmeds.price=900
    return nmeds.price*cart_quanity(nmeds,cart)
    
    
    
@register.filter(name='total_price')
def total_price(nmeds,cart):
    sum1=0
    for p in nmeds:
        sum1+=price_total(p ,cart)  
    return str(sum1)