

from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from demoapp.models import Customer, Vehicle, SignUp
from django.contrib.auth.models import User
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.hashers import make_password, check_password
from django.views import View
from demoapp.models import Vehicle

class Cart(View):
    def get(self, request):
        ids=list(request.session.get('cart').keys())
        vehiio=Vehicle.get_products_by_id(ids)
        #print("carttttttttttttt",ids)
        return render(request, 'cart.html',{'vehicle12':vehiio})

