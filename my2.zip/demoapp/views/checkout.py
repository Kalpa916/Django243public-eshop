
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from demoapp.models import Customer,SignUp,Vehicle,Order2
from django.contrib.auth.models import User
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.hashers import make_password, check_password
from django.views import View



class Checkout(View):
    def post(self,request):
        
        phone=request.POST.get('phone')
        cart=request.session.get('cart')
        product=Vehicle.get_products_by_id(list(cart.keys()))    
        print(phone,cart,product)
        return redirect ('cart')