from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from demoapp.models import Customer, Vehicle, SignUp
from django.contrib.auth.models import User
from django.contrib import messages

from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class Index(View):
    def get(self, request):
        cart = request.session.get('cart')
        if not cart:
            request.session['cart'] = {}
        mad = None

        custs = Customer.get_all_customer()
        categoryId = request.GET.get('customer')
        if(categoryId):
            mad = Vehicle.get_all_products_by_category_id(categoryId)
        else:
            mad = Vehicle.get_all_products()
        data = {'mad': mad, 'custs': custs}
        '''
        data['mad']=mad
        data['custs']=custs '''
        return render(request, 'base.html', data)

    def post(self, request):
        nmeds = request.POST.get('nmeds')
        remove = request.POST.get('remove')
        cart = request.session.get('cart')
        if cart:
            quantity = cart.get(nmeds)
            if(quantity):
                if remove:
                    if quantity <= 1:
                        cart.pop(nmeds)
                    else:
                        #cart[nmeds]= quantity+1
                        cart[nmeds] = quantity-1
                else:
                    cart[nmeds] = quantity+1

            else:
                cart[nmeds] = 1
        else:
            cart = {}
            cart[nmeds] = 1
        print("nmeds", cart.get(nmeds))
        request.session['cart'] = cart
        print(request.session['cart'])
        return redirect('homepage')

# {'mad':mad,'custs':custs}
