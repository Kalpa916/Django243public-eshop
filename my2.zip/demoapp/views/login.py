
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from demoapp.models import Customer, Vehicle, SignUp
from django.contrib.auth.models import User
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class Login(View):
    def get(self, request):
        return render(request, 'login.html')

    def post(self, request):

        postdat1 = request.POST
        email = postdat1.get('email')
        password1 = postdat1.get('password1')
        customer = SignUp.get_customer_by_email(email)
        error = None
        if customer:
            flag = check_password(password1, customer.password1)
            if flag:
                request.session['customer']=customer.id
                request.session['email']=customer.email
                return redirect('homepage')
            else:
                error = "emasil or password is invalid"

        else:
            error = "emasil or password is invalid"

        return render(request, 'login.html', {'errors': error})



def logout(request):
    request.session.clear()
    return redirect ('login')