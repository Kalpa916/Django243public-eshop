
from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from demoapp.models import Customer, Vehicle, SignUp,Order2
from django.contrib.auth.models import User
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class O12(View):

    def get(self,request):
        customer=request.session.get('customer')
        orders=Order2.get_orders_by_customer (customer)   
        print(orders)
        return render(request,'orders.html',{'ORD':orders})


