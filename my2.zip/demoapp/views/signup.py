

from django.http.response import HttpResponse
from django.shortcuts import redirect, render
from demoapp.models import Customer, Vehicle, SignUp
from django.contrib.auth.models import User
from django.contrib import messages
from django.views.decorators.csrf import csrf_protect
from django.contrib.auth.hashers import make_password, check_password
from django.views import View


class signup34(View):
    def get(self, request):
        return render(request, 'signup.html')

    def post(self, request):
        postData = request.POST
        first_name = postData.get('first_name')
        phone = postData.get('phone')
        email = postData.get('email')
        password1 = postData.get('password1')

        s = {'first_name': first_name, 'phone': phone,
             'email': email, 'password1': password1}

        f = SignUp(first_name=first_name, phone=phone,
                   email=email, password1=password1)
        error=self.validate_customer(f)

        if not error:

            f.password1 = make_password(f.password1)
            f.save()

            # return redirect('homepage')
            return HttpResponse("SignUp.register")
        else:
            data = {
                'errors': error,
                'values': s
            }
            
            return render(request, 'signup.html', data)

    def validate_customer(self,f):        
        error = None
        if (not f.first_name):
            error = "First Name Required"
        elif len(f.first_name) < 4:
            error = "First Name Can't Be less than four letters"
        elif (len(f.phone) < 9):
            error = "Mobile number must be 10 digits"
        elif(f.isexists()):
            error="email errord"
        return error
